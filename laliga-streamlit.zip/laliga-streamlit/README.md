# ⚽ LaLiga Analytics 2025/26 — Python & Streamlit

An interactive football analytics dashboard for the full **LaLiga 2025/26** season — all 380 matches, built in Python with **pandas**, **Plotly** and **Streamlit**.

![Season overview](screenshots/overview.png)

## Features

- **Overview** — league table with team badges (ties broken by head-to-head, as LaLiga does), match-result and goals-by-half donut charts, attack-vs-defence scatter, and shot conversion vs the league average.
- **Teams** — points race against the leader, every result with the half-time score, where the points came from (home / away), goals by half, and a home-vs-away comparison.
- **Compare** — any two teams side by side: a percentile radar across 8 metrics, head-to-head stats, and their meetings this season.
- **Matches** — all matches with filters (home wins, draws, away wins, won by 3+, 5+ goals, comebacks) and a team filter.
- **Import** — upload any other season or league in the football-data.co.uk CSV format from the sidebar, and download the current data as CSV.

| Teams | Compare | Matches |
|---|---|---|
| ![Teams](screenshots/teams.png) | ![Compare](screenshots/compare.png) | ![Matches](screenshots/matches.png) |

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

The app opens at http://localhost:8501.

## Deploy for free (Streamlit Community Cloud)

1. Push this folder to a GitHub repository.
2. Go to [share.streamlit.io](https://share.streamlit.io), sign in with GitHub and click **Create app**.
3. Pick the repository, branch `main` and main file `app.py`, then **Deploy**.

## Project structure

```
app.py                 # entry point: page setup, sidebar import, navigation
laliga.py              # data loading, league table (with head-to-head tie-break), badges, chart helpers
views/
  overview.py          # season overview
  teams.py             # one team in detail
  compare.py           # two teams side by side
  matches.py           # match list with filters
  common.py            # shared page header, KPI cards, form badges
data/laliga-2025-26.csv
.streamlit/config.toml # dark theme
```

## Data

- `data/laliga-2025-26.csv` — every match of the season: date, teams, full-time and half-time score, shots, shots on target, fouls, corners and cards.
- Source: [football-data.co.uk](https://www.football-data.co.uk/), via the open [datasets/football-datasets](https://github.com/datasets/football-datasets) repository (Public Domain Dedication and License, PDDL v1.0).
- The final table computed from this data matches the published 2025/26 standings.
- Match-level data only: there are no player stats and no expected goals (xG).

Team badges are simple shields in each club's colours — they are not the official club crests.

## Metrics

| Metric | Formula |
|---|---|
| Conversion | goals ÷ shots on target |
| Shot accuracy | shots on target ÷ shots |
| Percentile (radar) | rank of a team among all clubs, 0–100 (100 = best; ↓ axes reward lower values) |
| Comeback | losing at half-time, winning at full-time |

## Author

**Ashraf Hebish** — AI & Data Science student, Horus University (Egypt)

[GitHub](https://github.com/ashrafhebish) · [LinkedIn](https://www.linkedin.com/in/ashraf-hebish-b16370360)
