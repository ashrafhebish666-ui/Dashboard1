"""LaLiga Analytics 2025/26 — Streamlit dashboard.

Run:  streamlit run app.py
"""
import streamlit as st

import laliga as ll

st.set_page_config(page_title="LaLiga Analytics", page_icon="⚽", layout="wide")

st.markdown("""
<style>
.block-container{padding-top:2rem;max-width:1400px}
.kpi{border:1px solid rgba(143,161,150,.18);border-radius:14px;padding:14px 18px;height:100%}
.kpi .kl{text-transform:uppercase;letter-spacing:.06em;font-size:.76rem;font-weight:600;color:#8fa196}
.kpi .kv{font-size:1.9rem;font-weight:800;line-height:1.2;margin:4px 0 2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.kpi .ks{font-size:.84rem;color:#8fa196}
[data-testid="stMetric"]{background:var(--secondary-background-color);border:1px solid rgba(143,161,150,.18);border-radius:14px;padding:14px 18px}
[data-testid="stMetricLabel"] p{text-transform:uppercase;letter-spacing:.06em;font-size:.78rem;font-weight:600}
.badge-real{white-space:nowrap;font-size:.8rem;color:#ff5a4e;border:1px solid rgba(255,90,78,.45);border-radius:99px;padding:2px 10px;margin-left:8px;vertical-align:middle;font-weight:600}
.form span{display:inline-block;width:20px;height:20px;line-height:20px;text-align:center;border-radius:5px;font-size:11px;font-weight:800;color:#fff;margin-right:3px}
.form .W{background:#16a34a}.form .D{background:#6b7280}.form .L{background:#dc2626}
.res-row{display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid rgba(143,161,150,.15);font-size:.92rem}
.res-row .sc{margin-left:auto;font-weight:800;min-width:54px;text-align:center}.res-row .ht{color:#8fa196;font-size:.82rem;min-width:52px;text-align:right}
.res-row .dt{color:#8fa196;font-size:.82rem;min-width:52px}
</style>""", unsafe_allow_html=True)

# ---------------- data: default season or an uploaded file
if "matches" not in st.session_state:
    st.session_state.matches = ll.load_default()
    st.session_state.source = "LaLiga 2025/26"

with st.sidebar:
    st.markdown("### ⚽ LaLiga Analytics")
    up = st.file_uploader("Import a season (football-data.co.uk CSV)", type="csv")
    if up is not None and st.session_state.get("upload_name") != up.name:
        try:
            st.session_state.matches = ll.read_matches(up)
            st.session_state.source = up.name.removesuffix(".csv")
            st.session_state.upload_name = up.name
        except Exception as err:  # noqa: BLE001 — show any parsing problem to the user
            st.error(f"Could not read the file: {err}")
    if st.session_state.source != "LaLiga 2025/26" and st.button("Back to LaLiga 2025/26"):
        st.session_state.matches = ll.load_default()
        st.session_state.source = "LaLiga 2025/26"
        st.session_state.upload_name = None
        st.rerun()
    st.download_button("Download matches as CSV", ll.to_csv_bytes(st.session_state.matches),
                       file_name="matches.csv", mime="text/csv")
    st.caption("Data: football-data.co.uk via the open datasets/football-datasets repo. "
               "Match-level data only — no player stats or xG. Team badges are simple shields, not official crests.")

m = st.session_state.matches
st.session_state.table = ll.standings(m)
st.session_state.info = ll.team_info(m)

pages = [
    st.Page("views/overview.py", title="Overview", icon="🏆", default=True),
    st.Page("views/teams.py", title="Teams", icon="🛡️"),
    st.Page("views/compare.py", title="Compare", icon="⚔️"),
    st.Page("views/matches.py", title="Matches", icon="📅"),
]
st.navigation(pages, position="top").run()
