"""Small helpers shared by the pages."""
import streamlit as st


def header(title: str) -> None:
    m = st.session_state.matches
    real = st.session_state.source == "LaLiga 2025/26"
    st.markdown(f"## {title} <span class='badge-real'>{'Real data' if real else 'Imported'}</span>", unsafe_allow_html=True)
    st.caption(f"{st.session_state.source} · {len(st.session_state.table)} teams · {len(m)} matches · "
               f"{m['Date'].min():%d %b %Y} – {m['Date'].max():%d %b %Y}")


def form_html(form: str) -> str:
    return "<span class='form'>" + "".join(f"<span class='{r}'>{r}</span>" for r in form.split()) + "</span>"


def kpis(cards: list[tuple[str, str, str]], highlight_first: bool = False) -> None:
    """A row of KPI cards: (label, value, sub-text)."""
    cols = st.columns(len(cards))
    for i, (col, (label, value, sub)) in enumerate(zip(cols, cards)):
        bg = "linear-gradient(135deg,rgba(255,90,78,.18),transparent)" if highlight_first and i == 0 else "transparent"
        col.markdown(f"<div class='kpi' style='background:{bg}'><div class='kl'>{label}</div><div class='kv'>{value}</div><div class='ks'>{sub}</div></div>",
                     unsafe_allow_html=True)
