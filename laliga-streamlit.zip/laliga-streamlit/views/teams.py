import plotly.graph_objects as go
import streamlit as st

import laliga as ll
from views.common import form_html, header, kpis

m, t, info = st.session_state.matches, st.session_state.table, st.session_state.info
header("Teams")

names = t["Team"].tolist()
team = st.selectbox("Team", names, format_func=lambda n: f"{names.index(n) + 1}. {n}", key="team_pick")
r = t[t["Team"] == team].iloc[0]
lf = ll.long_format(m)
games = lf[lf["Team"] == team]
colour = info[team]["color"]

st.markdown(f"{ll.badge_html(team, info, 44)}<span style='font-size:1.5rem;font-weight:800'>{team}</span>"
            f"<span style='color:#8fa196;margin-left:12px'>{r['W']} wins · {r['D']} draw{'s' if r['D'] != 1 else ''} · {r['L']} losses</span>"
            f"<span style='margin-left:14px'>{form_html(r['Form'])}</span>", unsafe_allow_html=True)
kpis([("Position", ll.ordinal(int(r["Pos"])), f"of {len(t)}"), ("Points", int(r["Pts"]), f"{r['Pts'] / r['P']:.2f} per match"),
      ("Goals for", int(r["GF"]), f"{r['GF'] / r['P']:.2f} per match"), ("Goals against", int(r["GA"]), f"{r['GA'] / r['P']:.2f} per match"),
      ("Shots / match", f"{r['S'] / r['P']:.1f}", f"{r['Acc']:.0%} on target"), ("Clean sheets", int(r["CS"]), f"of {r['P']} matches")])

left, right = st.columns([1.6, 1], gap="large")
with left:
    st.subheader("Points race")
    st.caption("Cumulative points after each match.")
    fig = go.Figure()
    leader = t.iloc[0]["Team"]
    for name, grp in lf.groupby("Team"):
        if name in (team, leader):
            continue
        fig.add_trace(go.Scatter(x=grp["MatchNo"], y=grp["CumPts"], mode="lines", line=dict(color="rgba(143,161,150,.35)", width=1),
                                 name=name, showlegend=False, hovertemplate=f"{name}: " + "%{y} pts after %{x}<extra></extra>"))
    for name, col, width in ([(leader, "#94a3b8", 2.5)] if leader != team else []) + [(team, colour, 4)]:
        grp = lf[lf["Team"] == name]
        fig.add_trace(go.Scatter(x=grp["MatchNo"], y=grp["CumPts"], mode="lines", line=dict(color=col, width=width),
                                 name=name + (" (leader)" if name == leader and name != team else ""),
                                 customdata=grp[["Opp", "GF", "GA", "Venue"]],
                                 hovertemplate=f"<b>{name}</b> %{{y}} pts after match %{{x}}<br>%{{customdata[3]}} vs %{{customdata[0]}} %{{customdata[1]}}–%{{customdata[2]}}<extra></extra>"))
    fig.update_xaxes(title="Match")
    fig.update_yaxes(title="Points")
    st.plotly_chart(ll.style(fig, 400), width="stretch", config={"displayModeBar": False})
with right:
    st.subheader("Results")
    st.caption("Most recent first. Half-time score on the right.")
    rows = []
    for _, g in games.iloc[::-1].iterrows():
        rows.append(f"<div class='res-row'><span class='dt'>{g['Date']:%d %b}</span>{form_html(g['Res'])}"
                    f"{ll.badge_html(g['Opp'], info, 22)}<span>{'vs' if g['Venue'] == 'Home' else '@'} {g['Opp']}</span>"
                    f"<span class='sc'>{g['GF']} – {g['GA']}</span><span class='ht'>({g['HGF']} – {g['HGA']})</span></div>")
    st.html(f"<div style='max-height:400px;overflow:auto;font-family:Inter,Segoe UI,sans-serif;color:inherit'>"
            f"<style>.form span{{display:inline-block;width:20px;height:20px;line-height:20px;text-align:center;border-radius:5px;font-size:11px;font-weight:800;color:#fff}}"
            f".form .W{{background:#16a34a}}.form .D{{background:#6b7280}}.form .L{{background:#dc2626}}"
            f".res-row{{display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid rgba(143,161,150,.15);font-size:.92rem}}"
            f".res-row img{{margin-right:0!important}}.res-row .sc{{margin-left:auto;font-weight:800;min-width:54px;text-align:center}}"
            f".res-row .ht,.res-row .dt{{color:#8fa196;font-size:.82rem;min-width:52px}}.res-row .ht{{text-align:right}}</style>{''.join(rows)}</div>")

a, b, c3 = st.columns(3, gap="large")
with a:
    st.subheader("Where the points came from")
    st.plotly_chart(ll.donut(["Home", "Away"], [int(r["HomePts"]), int(r["AwayPts"])], [colour, "#94a3b8"], "POINTS", "Total Points"),
                    width="stretch", config={"displayModeBar": False})
with b:
    st.subheader("Goals by half")
    st.plotly_chart(ll.donut(["First half", "Second half"], [int(r["H1"]), int(r["H2"])], ["#f59e0b", "#8b5cf6"], "GOALS", "Goals Scored"),
                    width="stretch", config={"displayModeBar": False})
with c3:
    st.subheader("Home vs away")
    st.caption("Per match.")
    split = games.groupby("Venue").agg(Points=("Pts", "mean"), Scored=("GF", "mean"), Conceded=("GA", "mean")).T[["Home", "Away"]]
    fig = go.Figure([go.Bar(name="Home", x=split.index, y=split["Home"], marker_color=colour, text=split["Home"].round(2), textposition="outside"),
                     go.Bar(name="Away", x=split.index, y=split["Away"], marker_color="#94a3b8", text=split["Away"].round(2), textposition="outside")])
    fig.update_layout(barmode="group", bargap=.25)
    st.plotly_chart(ll.style(fig, 340), width="stretch", config={"displayModeBar": False})
