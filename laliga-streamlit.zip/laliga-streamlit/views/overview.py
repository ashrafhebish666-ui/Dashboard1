import plotly.graph_objects as go
import streamlit as st

import laliga as ll
from views.common import header, kpis

m, t, info = st.session_state.matches, st.session_state.table, st.session_state.info
header("Season overview")

goals = int(m["FTHG"].sum() + m["FTAG"].sum())
leader, best_att, best_def = t.iloc[0], t.sort_values("GF", ascending=False).iloc[0], t.sort_values("GA").iloc[0]
finished = leader["P"] >= 2 * (len(t) - 1)
kpis([("Champion" if finished else "Leader", leader["Team"], f"{leader['Pts']} pts · {leader['W']}W {leader['D']}D {leader['L']}L · +{leader['Pts'] - t.iloc[1]['Pts']} clear"),
      ("Goals per match", f"{goals / len(m):.2f}", f"{goals:,} goals in {len(m)} matches"),
      ("Best attack", best_att["Team"], f"{best_att['GF']} goals · {best_att['GF'] / best_att['P']:.2f} per match"),
      ("Best defence", best_def["Team"], f"{best_def['GA']} conceded · {best_def['CS']} clean sheets")], highlight_first=True)

left, right = st.columns([2, 1], gap="large")
with left:
    st.subheader("League table")
    st.caption("Ties broken by head-to-head, then goal difference. Bottom three are relegated.")
    view = t.assign(Badge=t["Team"].map(lambda x: ll.badge_uri(x, info)))[["Pos", "Badge", "Team", "Pts", "P", "W", "D", "L", "GF", "GA", "GD", "Form"]]
    rel = len(t) - 3

    def zone(row):
        colour = "rgba(234,179,8,.16)" if row["Pos"] == 1 else "rgba(220,38,38,.14)" if row["Pos"] > rel else ""
        return [f"background-color:{colour}" if colour else ""] * len(row)

    st.dataframe(view.style.apply(zone, axis=1), hide_index=True, width="stretch", height=36 * (len(t) + 1) + 4,
                 column_config={"Pos": st.column_config.NumberColumn("#", width=36),
                                "Badge": st.column_config.ImageColumn("", width=40),
                                "Team": st.column_config.TextColumn("Team", width=135),
                                **{k: st.column_config.NumberColumn(k, width=44) for k in ("P", "W", "D", "L", "GF", "GA")},
                                "GD": st.column_config.NumberColumn("GD", format="%+d", width=52),
                                "Form": st.column_config.TextColumn("Last 5", help="Most recent on the right", width=100),
                                "Pts": st.column_config.NumberColumn("Pts", width=50)})
with right:
    hw, dr = int((m["FTHG"] > m["FTAG"]).sum()), int((m["FTHG"] == m["FTAG"]).sum())
    st.subheader("Match results")
    st.plotly_chart(ll.donut(["Home wins", "Draws", "Away wins"], [hw, dr, len(m) - hw - dr], [ll.ACCENT, "#94a3b8", ll.ACCENT2], "MATCHES", "Total Matches"),
                    width="stretch", config={"displayModeBar": False})
    g1 = int(m["HTHG"].sum() + m["HTAG"].sum())
    st.subheader("Goals by half")
    st.plotly_chart(ll.donut(["First half", "Second half"], [g1, goals - g1], ["#f59e0b", "#8b5cf6"], "GOALS", "Total Goals"),
                    width="stretch", config={"displayModeBar": False})

a, b = st.columns(2, gap="large")
with a:
    st.subheader("Attack vs defence")
    st.caption("Goals per match. Right = scores more, up = concedes less.")
    x, y = t["GF"] / t["P"], t["GA"] / t["P"]
    fig = go.Figure(go.Scatter(x=x, y=y, mode="markers+text", text=[info[n]["code"] for n in t["Team"]],
                               textfont=dict(size=9, color=["#111" if ll._lum(info[n]["color"]) > .6 else "#fff" for n in t["Team"]]),
                               marker=dict(size=30, color=[info[n]["color"] for n in t["Team"]], line=dict(width=1.5, color="#111813")),
                               customdata=t[["Team", "Pts", "Pos"]], hovertemplate="<b>%{customdata[0]}</b><br>Scores %{x:.2f} · concedes %{y:.2f} per match<br>%{customdata[1]} pts · #%{customdata[2]}<extra></extra>"))
    fig.add_vline(x=x.mean(), line_dash="dot", line_color=ll.MUTED)
    fig.add_hline(y=y.mean(), line_dash="dot", line_color=ll.MUTED)
    for txt, xa, ya, xan in [("STRONG BOTH WAYS", 1, 1, "right"), ("DEFENCE FIRST", 0, 1, "left"), ("ATTACK FIRST", 1, 0, "right"), ("WEAK BOTH WAYS", 0, 0, "left")]:
        fig.add_annotation(text=txt, x=xa, y=ya, xref="paper", yref="paper", xanchor=xan, yanchor="top" if ya else "bottom", showarrow=False, font=dict(size=10, color=ll.MUTED))
    fig.update_yaxes(autorange="reversed", title="Goals conceded per match (fewer ↑)")
    fig.update_xaxes(title="Goals scored per match →")
    st.plotly_chart(ll.style(fig, 430), width="stretch", config={"displayModeBar": False})
with b:
    st.subheader("Finishing")
    st.caption("Share of shots on target that became goals, vs the league average.")
    avg = t["GF"].sum() / t["ST"].sum()
    f = t.assign(diff=t["Conv"] - avg).sort_values("diff")
    fig = go.Figure(go.Bar(x=f["diff"] * 100, y=f["Team"], orientation="h", marker_color=["#16a34a" if v >= 0 else "#dc2626" for v in f["diff"]],
                           text=[f"{v:.0%}" for v in f["Conv"]], textposition="outside", cliponaxis=False,
                           customdata=f[["GF", "ST", "Conv"]], hovertemplate="<b>%{y}</b><br>%{customdata[0]} goals from %{customdata[1]} shots on target<br>%{customdata[2]:.0%} vs league " + f"{avg:.0%}<extra></extra>"))
    lo, hi = f["diff"].min() * 100, f["diff"].max() * 100
    fig.update_xaxes(title=f"Percentage points vs league average ({avg:.0%})", ticksuffix=" pts", range=[lo * 1.45, hi * 1.3])
    st.plotly_chart(ll.style(fig, 560), width="stretch", config={"displayModeBar": False})
