import plotly.graph_objects as go
import streamlit as st

import laliga as ll
from views.common import header

m, t, info = st.session_state.matches, st.session_state.table, st.session_state.info
header("Compare teams")

names = t["Team"].tolist()
c1, c2 = st.columns(2)
a = c1.selectbox("Team A", names, index=0, format_func=lambda n: f"{names.index(n) + 1}. {n}")
b = c2.selectbox("Team B", names, index=1, format_func=lambda n: f"{names.index(n) + 1}. {n}")
A, B = t[t["Team"] == a].iloc[0], t[t["Team"] == b].iloc[0]
ca, cb = info[a]["color"], info[b]["color"]
if a != b and abs(ll._lum(ca) - ll._lum(cb)) < .12:
    cb = ll.ACCENT2
for col, row in ((c1, A), (c2, B)):
    col.markdown(f"{ll.badge_html(row['Team'], info, 34)}<b>{ll.ordinal(int(row['Pos']))}</b> · {row['Pts']} pts · {row['W']}W {row['D']}D {row['L']}L", unsafe_allow_html=True)

# percentile of each team among all teams (100 = best); "fewer" metrics are negated so higher = better
P = t["P"]
metrics = {
    "Goals": t["GF"] / P, "Shots": t["S"] / P, "Accuracy": t["Acc"], "Conversion": t["Conv"],
    "Conceded ↓": -t["GA"] / P, "Shots faced ↓": -t["SA"] / P, "Corners": t["C"] / P, "Cards ↓": -(t["Y"] + 2 * t["R"]) / P,
}
pct = {k: v.rank(pct=False, method="average").sub(1).div(len(t) - 1).mul(100).round() for k, v in metrics.items()}

left, right = st.columns(2, gap="large")
with left:
    st.subheader("Percentile radar")
    st.caption(f"Each axis = rank among the {len(t)} teams (100 = best). Per-match rates; ↓ axes reward lower numbers.")
    fig = go.Figure()
    axes = list(metrics)
    for row, col in ((A, ca), (B, cb)):
        i = t.index[t["Team"] == row["Team"]][0]
        vals = [pct[k][i] for k in axes]
        fig.add_trace(go.Scatterpolar(r=vals + vals[:1], theta=axes + axes[:1], fill="toself", name=row["Team"],
                                      line=dict(color=col, width=3), opacity=.75, hovertemplate="%{theta}: %{r:.0f}th percentile<extra>" + row["Team"] + "</extra>"))
    fig.update_layout(polar=dict(bgcolor="rgba(0,0,0,0)", radialaxis=dict(range=[0, 100], showticklabels=False, gridcolor=ll.GRID),
                                 angularaxis=dict(gridcolor=ll.GRID, rotation=90, direction="clockwise")))
    fig = ll.style(fig, 480)
    fig.update_layout(margin=dict(l=90, r=90, t=30, b=30))
    st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})
with right:
    st.subheader("Head to head")
    st.caption("Season totals and per-match rates. Green = better.")
    rows = [("Points", A["Pts"], B["Pts"], "{:.0f}", False), ("Goals for", A["GF"], B["GF"], "{:.0f}", False), ("Goals against", A["GA"], B["GA"], "{:.0f}", True),
            ("Clean sheets", A["CS"], B["CS"], "{:.0f}", False), ("Shots / match", A["S"] / A["P"], B["S"] / B["P"], "{:.1f}", False),
            ("Shot accuracy", A["Acc"], B["Acc"], "{:.0%}", False), ("Conversion", A["Conv"], B["Conv"], "{:.0%}", False),
            ("Shots allowed / match", A["SA"] / A["P"], B["SA"] / B["P"], "{:.1f}", True), ("Corners / match", A["C"] / A["P"], B["C"] / B["P"], "{:.1f}", False),
            ("Yellow cards", A["Y"], B["Y"], "{:.0f}", True), ("Red cards", A["R"], B["R"], "{:.0f}", True)]

    def cell(v, other, fmt, low):
        better = v < other if low else v > other
        return f"<td style='text-align:center;font-weight:{800 if better else 400};color:{'#16a34a' if better else 'inherit'}'>{fmt.format(v)}</td>"

    html = "".join(f"<tr>{cell(x, y, f, lo)}<td style='text-align:center;color:#8fa196'>{lab}</td>{cell(y, x, f, lo)}</tr>" for lab, x, y, f, lo in rows)
    st.html(f"<table style='width:100%;border-collapse:collapse;font-family:Inter,Segoe UI,sans-serif;font-size:15px'>"
            f"<tr><th style='color:{ca};padding:6px'>{a}</th><th></th><th style='color:{cb};padding:6px'>{b}</th></tr>{html}</table>"
            "<style>td{padding:7px 4px;border-bottom:1px solid rgba(143,161,150,.15)}</style>")
    st.subheader("Meetings this season")
    meet = m[((m["Home"] == a) & (m["Away"] == b)) | ((m["Home"] == b) & (m["Away"] == a))]
    if meet.empty or a == b:
        st.caption("They did not meet in this data.")
    for _, g in meet.iterrows():
        st.markdown(f"{g['Date']:%d %b %Y} · {ll.badge_html(g['Home'], info, 22)}**{g['Home']} {g['FTHG']} – {g['FTAG']} {g['Away']}** "
                    f"<span style='color:#8fa196'>(HT {g['HTHG']}–{g['HTAG']})</span>", unsafe_allow_html=True)
