import streamlit as st

import laliga as ll
from views.common import header, kpis

m, t, info = st.session_state.matches, st.session_state.table, st.session_state.info
header("Matches")

res = (m["FTHG"] > m["FTAG"]).map({True: "H", False: ""}) + (m["FTHG"] < m["FTAG"]).map({True: "A", False: ""})
res = res.replace("", "D")
ht = (m["HTHG"] > m["HTAG"]).map({True: "H", False: ""}) + (m["HTHG"] < m["HTAG"]).map({True: "A", False: ""})
ht = ht.replace("", "D")
comeback = (ht != "D") & (res != "D") & (ht != res)
margin, total = (m["FTHG"] - m["FTAG"]).abs(), m["FTHG"] + m["FTAG"]

big = m.loc[(margin * 100 + total).idxmax()]
most = m.loc[total.idxmax()]
kpis([("Biggest win", f"{big['FTHG']}–{big['FTAG']}", f"{big['Home']} vs {big['Away']} · {big['Date']:%d %b %Y}"),
      ("Most goals", int(total.max()), f"{most['Home']} {most['FTHG']}–{most['FTAG']} {most['Away']}"),
      ("0–0 draws", int((total == 0).sum()), f"of {len(m)} matches"), ("Comebacks", int(comeback.sum()), "losing at half-time, won at full-time")])

f1, f2 = st.columns([2, 1])
kind = f1.segmented_control("Show", ["All", "Home wins", "Draws", "Away wins", "Won by 3+", "5+ goals", "Comebacks"], default="All")
team = f2.selectbox("Team", ["All teams"] + t["Team"].tolist())
mask = {"Home wins": res == "H", "Draws": res == "D", "Away wins": res == "A", "Won by 3+": margin >= 3, "5+ goals": total >= 5, "Comebacks": comeback}.get(kind or "All")
view = m if mask is None else m[mask]
if team != "All teams":
    view = view[(view["Home"] == team) | (view["Away"] == team)]

out = view.iloc[::-1].assign(
    HomeBadge=lambda d: d["Home"].map(lambda x: ll.badge_uri(x, info)),
    AwayBadge=lambda d: d["Away"].map(lambda x: ll.badge_uri(x, info)),
    Score=lambda d: d["FTHG"].astype(str) + " – " + d["FTAG"].astype(str),
    HT=lambda d: d["HTHG"].astype(str) + "–" + d["HTAG"].astype(str),
    Shots=lambda d: d["HS"].astype(str) + "–" + d["AS"].astype(str),
    OnTarget=lambda d: d["HST"].astype(str) + "–" + d["AST"].astype(str),
    Corners=lambda d: d["HC"].astype(str) + "–" + d["AC"].astype(str),
    Cards=lambda d: d["HY"] + d["AY"] + 2 * (d["HR"] + d["AR"]),
)[["Date", "HomeBadge", "Home", "Score", "AwayBadge", "Away", "HT", "Shots", "OnTarget", "Corners", "Cards"]]
st.dataframe(out, hide_index=True, width="stretch", height=620,
             column_config={"Date": st.column_config.DateColumn("Date", format="D MMM YYYY"),
                            "HomeBadge": st.column_config.ImageColumn("", width=40), "AwayBadge": st.column_config.ImageColumn("", width=40),
                            "Score": st.column_config.TextColumn("Score", width="small"), "OnTarget": "On target",
                            "Cards": st.column_config.NumberColumn("Cards", help="Yellow cards + 2 × red cards")})
st.caption(f"{len(out)} matches shown · stats are home–away.")
