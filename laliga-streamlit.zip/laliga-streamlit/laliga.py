"""Data loading, league table and chart helpers for the LaLiga Analytics app."""
from __future__ import annotations

import base64
import io
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

DATA_FILE = Path(__file__).parent / "data" / "laliga-2025-26.csv"

# football-data.co.uk short names -> display name, 3-letter code, two club colours
TEAMS: dict[str, tuple[str, str, str, str]] = {
    "Barcelona": ("Barcelona", "BAR", "#a50044", "#004d98"),
    "Real Madrid": ("Real Madrid", "RMA", "#d4a017", "#f5f5f5"),
    "Villarreal": ("Villarreal", "VIL", "#f2c200", "#005187"),
    "Ath Madrid": ("Atletico Madrid", "ATM", "#c8102e", "#f5f5f5"),
    "Betis": ("Real Betis", "BET", "#0bb363", "#f5f5f5"),
    "Celta": ("Celta Vigo", "CEL", "#5fa8d8", "#f5f5f5"),
    "Getafe": ("Getafe", "GET", "#005999", "#f5f5f5"),
    "Vallecano": ("Rayo Vallecano", "RAY", "#e53027", "#f5f5f5"),
    "Valencia": ("Valencia", "VAL", "#f18a00", "#111111"),
    "Sociedad": ("Real Sociedad", "RSO", "#0067b1", "#f5f5f5"),
    "Espanol": ("Espanyol", "ESP", "#1e88e5", "#f5f5f5"),
    "Ath Bilbao": ("Athletic Bilbao", "ATH", "#ee2523", "#f5f5f5"),
    "Sevilla": ("Sevilla", "SEV", "#d71920", "#f5f5f5"),
    "Alaves": ("Alaves", "ALA", "#1d4ed8", "#f5f5f5"),
    "Elche": ("Elche", "ELC", "#05642c", "#f5f5f5"),
    "Levante": ("Levante", "LEV", "#9e1b32", "#00428e"),
    "Osasuna": ("Osasuna", "OSA", "#b91c1c", "#0a2240"),
    "Mallorca": ("Mallorca", "MLL", "#e20613", "#111111"),
    "Girona": ("Girona", "GIR", "#cd2534", "#f5f5f5"),
    "Oviedo": ("Real Oviedo", "OVI", "#0055a4", "#f5f5f5"),
}
PALETTE = ["#e11d48", "#2563eb", "#16a34a", "#f59e0b", "#7c3aed", "#0891b2", "#ea580c", "#dc2626",
           "#ca8a04", "#0d9488", "#db2777", "#4f46e5", "#65a30d", "#0369a1", "#9333ea", "#b45309"]
STAT_COLS = ["FTHG", "FTAG", "HTHG", "HTAG", "HS", "AS", "HST", "AST", "HF", "AF", "HC", "AC", "HY", "AY", "HR", "AR"]

ACCENT, ACCENT2, MUTED, GRID = "#ff5a4e", "#38bdf8", "#8fa196", "rgba(143,161,150,.18)"


# ---------------------------------------------------------------- data
def read_matches(source) -> pd.DataFrame:
    """Read a football-data.co.uk CSV (path or uploaded file) into a tidy match table."""
    df = pd.read_csv(source)
    missing = {"Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG"} - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {', '.join(sorted(missing))}")
    df = df.dropna(subset=["HomeTeam", "AwayTeam", "FTHG", "FTAG"]).copy()
    for c in STAT_COLS:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0).astype(int) if c in df else 0
    raw = df["Date"].astype(str).str.strip()
    iso = raw.str.match(r"^\d{4}-\d{2}-\d{2}")  # 2025-08-15 (this repo) vs 15/08/2025 (football-data.co.uk)
    df["Date"] = pd.to_datetime(raw.where(iso), format="%Y-%m-%d", errors="coerce").fillna(
        pd.to_datetime(raw.where(~iso), dayfirst=True, errors="coerce"))
    df = df.dropna(subset=["Date"])
    names = {k: v[0] for k, v in TEAMS.items()}
    df["Home"] = df["HomeTeam"].map(lambda t: names.get(t, t))
    df["Away"] = df["AwayTeam"].map(lambda t: names.get(t, t))
    return df.sort_values("Date", kind="stable").reset_index(drop=True)[["Date", "Home", "Away", *STAT_COLS]]


@st.cache_data
def load_default() -> pd.DataFrame:
    return read_matches(DATA_FILE)


def team_info(matches: pd.DataFrame) -> dict[str, dict]:
    known = {v[0]: v for v in TEAMS.values()}
    teams = sorted(set(matches["Home"]) | set(matches["Away"]))
    info = {}
    for i, t in enumerate(teams):
        if t in known:
            _, code, c1, c2 = known[t]
        else:
            code = "".join(ch for ch in t if ch.isalpha())[:3].upper()
            c1, c2 = PALETTE[i % len(PALETTE)], "#f5f5f5"
        info[t] = {"code": code, "color": c1, "color2": c2}
    return info


def long_format(m: pd.DataFrame) -> pd.DataFrame:
    """One row per team per match (the match seen from that team's side)."""
    home = pd.DataFrame({"Date": m["Date"], "Team": m["Home"], "Opp": m["Away"], "Venue": "Home",
                         "GF": m["FTHG"], "GA": m["FTAG"], "HGF": m["HTHG"], "HGA": m["HTAG"],
                         "S": m["HS"], "SA": m["AS"], "ST": m["HST"], "STA": m["AST"],
                         "C": m["HC"], "F": m["HF"], "Y": m["HY"], "R": m["HR"]})
    away = pd.DataFrame({"Date": m["Date"], "Team": m["Away"], "Opp": m["Home"], "Venue": "Away",
                         "GF": m["FTAG"], "GA": m["FTHG"], "HGF": m["HTAG"], "HGA": m["HTHG"],
                         "S": m["AS"], "SA": m["HS"], "ST": m["AST"], "STA": m["HST"],
                         "C": m["AC"], "F": m["AF"], "Y": m["AY"], "R": m["AR"]})
    lf = pd.concat([home, away]).sort_values(["Team", "Date"], kind="stable").reset_index(drop=True)
    lf["Res"] = (lf["GF"] > lf["GA"]).map({True: "W", False: ""}) + (lf["GF"] == lf["GA"]).map({True: "D", False: ""})
    lf.loc[lf["Res"] == "", "Res"] = "L"
    lf["Pts"] = lf["Res"].map({"W": 3, "D": 1, "L": 0})
    lf["MatchNo"] = lf.groupby("Team").cumcount() + 1
    lf["CumPts"] = lf.groupby("Team")["Pts"].cumsum()
    return lf


def standings(m: pd.DataFrame) -> pd.DataFrame:
    """League table. LaLiga tie-break: head-to-head points, head-to-head goal difference,
    then overall goal difference and goals scored."""
    lf = long_format(m)
    g = lf.groupby("Team")
    t = pd.DataFrame({
        "P": g.size(), "W": g["Res"].apply(lambda s: (s == "W").sum()), "D": g["Res"].apply(lambda s: (s == "D").sum()),
        "L": g["Res"].apply(lambda s: (s == "L").sum()), "GF": g["GF"].sum(), "GA": g["GA"].sum(), "Pts": g["Pts"].sum(),
        "S": g["S"].sum(), "SA": g["SA"].sum(), "ST": g["ST"].sum(), "C": g["C"].sum(), "Y": g["Y"].sum(), "R": g["R"].sum(),
        "CS": g["GA"].apply(lambda s: (s == 0).sum()), "H1": g["HGF"].sum(),
        "HomePts": lf[lf["Venue"] == "Home"].groupby("Team")["Pts"].sum(),
        "AwayPts": lf[lf["Venue"] == "Away"].groupby("Team")["Pts"].sum(),
        "Form": g["Res"].apply(lambda s: " ".join(s.tail(5))),
    }).fillna(0)
    t["GD"] = t["GF"] - t["GA"]
    t["H2"] = t["GF"] - t["H1"]
    t["Conv"] = (t["GF"] / t["ST"]).where(t["ST"] > 0, 0)
    t["Acc"] = (t["ST"] / t["S"]).where(t["S"] > 0, 0)
    t = t.reset_index().rename(columns={"index": "Team"})

    ordered = []
    for _, grp in t.sort_values("Pts", ascending=False).groupby("Pts", sort=False):
        if len(grp) > 1:
            tied = set(grp["Team"])
            mini = lf[lf["Team"].isin(tied) & lf["Opp"].isin(tied)]
            h2h = mini.groupby("Team").agg(h2h_pts=("Pts", "sum"), gf=("GF", "sum"), ga=("GA", "sum"))
            h2h["h2h_gd"] = h2h["gf"] - h2h["ga"]
            grp = grp.merge(h2h[["h2h_pts", "h2h_gd"]], left_on="Team", right_index=True, how="left").fillna({"h2h_pts": 0, "h2h_gd": 0})
            grp = grp.sort_values(["h2h_pts", "h2h_gd", "GD", "GF", "Team"], ascending=[False, False, False, False, True])
            grp = grp.drop(columns=["h2h_pts", "h2h_gd"])
        ordered.append(grp)
    table = pd.concat(ordered).reset_index(drop=True)
    table.insert(0, "Pos", range(1, len(table) + 1))
    return table


# ---------------------------------------------------------------- badges
def badge_svg(code: str, c1: str, c2: str) -> str:
    """A simple two-colour shield with the team code (not an official crest)."""
    light = _lum(c1) > 0.6
    shield = "M12 1.2 L22.2 4.4 V13.2 C22.2 19.6 17.8 24.4 12 26.8 C6.2 24.4 1.8 19.6 1.8 13.2 V4.4 Z"
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 28" width="48" height="56">'
            f'<defs><clipPath id="c"><path d="{shield}"/></clipPath></defs>'
            f'<g clip-path="url(#c)"><rect width="24" height="28" fill="{c1}"/><rect x="12" width="12" height="28" fill="{c2}"/>'
            f'<rect width="24" height="9.2" fill="{c1}"/></g><path d="{shield}" fill="none" stroke="rgba(0,0,0,.35)"/>'
            f'<text x="12" y="7.6" text-anchor="middle" font-family="Arial,sans-serif" font-size="6.2" font-weight="800" '
            f'fill="{"#111" if light else "#fff"}">{code}</text></svg>')


def badge_uri(team: str, info: dict) -> str:
    k = info[team]
    return "data:image/svg+xml;base64," + base64.b64encode(badge_svg(k["code"], k["color"], k["color2"]).encode()).decode()


def badge_html(team: str, info: dict, size: int = 26) -> str:
    return f'<img src="{badge_uri(team, info)}" width="{size}" style="vertical-align:middle;margin-right:8px">'


def _lum(hex_color: str) -> float:
    h = hex_color.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255


# ---------------------------------------------------------------- charts
def style(fig: go.Figure, height: int = 360) -> go.Figure:
    fig.update_layout(height=height, margin=dict(l=10, r=10, t=10, b=10), paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)", font=dict(family="Inter, Segoe UI, sans-serif", size=13),
                      legend=dict(orientation="h", y=-0.12), hoverlabel=dict(font_size=13))
    fig.update_xaxes(gridcolor=GRID, zeroline=False)
    fig.update_yaxes(gridcolor=GRID, zeroline=False)
    return fig


def donut(labels: list[str], values: list[float], colors: list[str], top: str, caption: str) -> go.Figure:
    total = sum(values)
    fig = go.Figure(go.Pie(labels=labels, values=values, hole=0.6, sort=False, direction="clockwise",
                           marker=dict(colors=colors, line=dict(color="#111813", width=3)),
                           textinfo="percent", textfont=dict(size=13, color="#fff"),
                           hovertemplate="%{label}: %{value} (%{percent})<extra></extra>"))
    for txt, y, size, colour, bold in ((top, 0.62, 12, MUTED, False), (f"{total:,.0f}", 0.5, 30, None, True), (caption, 0.38, 12, MUTED, False)):
        fig.add_annotation(text=f"<b>{txt}</b>" if bold else txt, x=0.5, y=y, xref="paper", yref="paper", showarrow=False,
                           font=dict(size=size, color=colour) if colour else dict(size=size))
    fig.update_layout(showlegend=True)
    return style(fig, 340)


def to_csv_bytes(m: pd.DataFrame) -> bytes:
    out = m.copy()
    out["Date"] = out["Date"].dt.strftime("%Y-%m-%d")
    out = out.rename(columns={"Home": "HomeTeam", "Away": "AwayTeam"})
    buf = io.StringIO()
    out.to_csv(buf, index=False)
    return buf.getvalue().encode()


def ordinal(n: int) -> str:
    return f"{n}{'th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"
